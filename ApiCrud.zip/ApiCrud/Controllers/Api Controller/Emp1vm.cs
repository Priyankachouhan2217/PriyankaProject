﻿using ApiCrud.Models;

namespace ApiCrud.Controllers.Api_Controller
{
    //internal class Emp1vm
    //{
    //    public object tb_parts_order { get; set; }
    //    public object tb_parts_orderpart { get; set; }
    //    public object tb_parts_vendor { get; set; }
    //    public Emp1 tb_parts_warehouse { get; set; }
    //    public EmpAdd tb_parts_part { get; set; }
    //}
}